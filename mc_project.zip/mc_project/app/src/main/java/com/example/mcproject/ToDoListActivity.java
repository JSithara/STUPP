package com.example.mcproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ToDoListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.to_do_list_activity);
    }
}
